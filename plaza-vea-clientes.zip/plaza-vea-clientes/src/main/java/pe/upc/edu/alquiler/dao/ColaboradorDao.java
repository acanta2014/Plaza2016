package pe.upc.edu.alquiler.dao;

import pe.upc.edu.alquiler.model.Colaborador;




public interface ColaboradorDao {
	
	public Colaborador obtenerColaborador(long idColaborador) throws Exception;
	
}
