package pe.upc.edu.alquiler.dao;

import pe.upc.edu.alquiler.model.InfEvalMerc;;




public interface InfEvalMercDao {
	
	public InfEvalMerc obtenerInfEvalMerc(long idEvaluacion) throws Exception;
	
}
