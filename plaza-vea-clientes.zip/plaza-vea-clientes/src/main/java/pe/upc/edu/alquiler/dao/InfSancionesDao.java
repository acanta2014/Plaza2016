package pe.upc.edu.alquiler.dao;

import pe.upc.edu.alquiler.model.InfSanciones;;




public interface InfSancionesDao {
	
	public InfSanciones obtenerInfSanciones(long idEvaluacion) throws Exception;
	
}
