package pe.upc.edu.alquiler.dao.impl;

import java.util.Date;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pe.upc.edu.alquiler.dao.EvaluadorDao;
import pe.upc.edu.alquiler.model.Evaluador;
import pe.upc.edu.spring.configuration.AbstractDao;

@Transactional
@Repository("evaluadorDao")
public class EvaluadorMySqlDaoImpl extends AbstractDao implements EvaluadorDao {
	
	public Evaluador obtenerEvaluador(long idEvaluador) throws Exception {
		Evaluador evaluador = (Evaluador)getSession()
        							.createQuery("from Evaluador where idEvaluador = " + idEvaluador).list();
        return evaluador;
	}

	@Override
	public Evaluador evaluadorDisponible() throws Exception {
		// TODO Auto-generated method stub
		
		Query query = getSession().createQuery("from Evaluador where estado = 'Disponible' ");
		query.setMaxResults(1);
		Evaluador evaluador = (Evaluador) query.uniqueResult();
		return evaluador;
	}

	@Override
	public int actualizarEvaluador(long idEvaluador, String estado, Date fechaProp) throws Exception {
		String hql = "update Evaluador set estado = :estado, fechaAct= :fecPro, actividad = :act where idEvaluador = :id";
		 
		Query query = getSession().createQuery(hql);
		query.setParameter("estado", estado);
		if(estado.equals("Disponible")){
			query.setParameter("fecPro",null);
			query.setParameter("act",null);
		}
		else{
		query.setParameter("fecPro", fechaProp);
		query.setParameter("act", "Evaluando solicitud de alquiler");
		}
		query.setParameter("id", idEvaluador);
		 
		int rowsAffected = query.executeUpdate();
		if (rowsAffected > 0) {
		    System.out.println("Updated " + rowsAffected + " rows.");
		}
		return 1;
	}
	
}
