package pe.upc.edu.alquiler.mbeans;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import pe.upc.edu.alquiler.model.Evaluacion;
import pe.upc.edu.alquiler.model.InfEstEmp;
import pe.upc.edu.alquiler.model.InfEvalMerc;
import pe.upc.edu.alquiler.model.InfSanciones;
import pe.upc.edu.alquiler.service.AlquilerService;
import pe.upc.edu.alquiler.util.EnvioMail;

@ManagedBean(name="evaluacionMBean")
@RequestScoped
@Component
public class EvaluacionMBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Evaluacion> listaEvaluaciones;
	private Evaluacion evaluacion;
	
	@Autowired
	private AlquilerService alquilerService;
	
	private InfEstEmp infEstEmp;
	private InfSanciones infSanciones;
	private InfEvalMerc infEvalMerc;
	
	private Boolean disabled = true;
	
	//@EJB
    //private EvaluacionSessionBean evaluacionSessionBean;
	
	public EvaluacionMBean() {
	}
	
	public int getObtenerEvaluaciones() {
		try {
			this.listaEvaluaciones = this.alquilerService.listarEvaluaciones();
			
			//this.listaEvaluaciones = evaluacionSessionBean.listarEvaluaciones();
			System.out.println(listaEvaluaciones.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}
	
	public void showSelectedEval(ActionEvent event){
		try {
			//this.evaluacion = this.alquilerService.obtenerEvaluacion(idEvaluacion);
			this.evaluacion = (Evaluacion) event.getComponent().getAttributes().get("eval");
			System.out.println("Evaluacion: " + evaluacion.getIdEvaluacion());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void delSelectedEval(ActionEvent event){
		
		FacesContext context = FacesContext.getCurrentInstance();
		
		try {
			//this.evaluacion = this.alquilerService.obtenerEvaluacion(idEvaluacion);
			this.evaluacion = (Evaluacion) event.getComponent().getAttributes().get("eval");
			System.out.println("Evaluacion: " + evaluacion.getIdEvaluacion());
			int actEval = 0;
			    evaluacion.setObservacion("La evaluacion ha sido eliminada");
				evaluacion.setEstado("Eliminada");
			
				actEval =  this.alquilerService.actualizarEvaluacion(evaluacion);
				if(actEval > 0){
					this.alquilerService.actualizarEvaluador(evaluacion.getEvaluador().getIdEvaluador(), "Disponible", null);
					this.alquilerService.actualizarSolicitud(evaluacion.getSolicitud().getIdSolicitud(), "Eliminada");
					context.addMessage(null, new FacesMessage("Información",  "La evaluación fue eliminada satisfactoriamente") );
				}
				else
					context.addMessage(null, new FacesMessage("Error",  "La evaluación presento problemas al ser eliminada") );
				
				context.getExternalContext().getFlash().setKeepMessages(true);
				  
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	 public String goListPage() {
		   return "evaluaciones";
	   }

	   public String goEditPage() {
		   return "evaluacion";
	   }
	
	   public void getObtenerInformes() {
			try {				
				
				this.infEstEmp = this.alquilerService.obtenerInfEstEmp(evaluacion.getIdEvaluacion());
				this.infSanciones = this.alquilerService.obtenerInfSanciones(evaluacion.getIdEvaluacion());
				this.infEvalMerc = this.alquilerService.obtenerInfEvalMerc(evaluacion.getIdEvaluacion());
				
				InformesMBean infMBean = new InformesMBean();
				infMBean.setInfEstEmp(infEstEmp);
				infMBean.setInfSanciones(infSanciones);
				infMBean.setInfEvalMerc(infEvalMerc);
				
				Map<String,Object> options = new HashMap<String, Object>();
		        options.put("resizable", true);
		        options.put("draggable", true);
		        options.put("modal", true);
		        RequestContext.getCurrentInstance().openDialog("informes", options, null);
		    
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	   
	   public void onCarChosen(SelectEvent event) {
	        Evaluacion eval = (Evaluacion) event.getObject();
	        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Car Selected", "Id:" + eval.getIdEvaluacion());
	         
	        FacesContext.getCurrentInstance().addMessage(null, message);
	    }
	
	public String actualizarEvaluacion() {
		
		FacesContext context = FacesContext.getCurrentInstance();
		
		int actEval = 0;
		try {
			actEval =  this.alquilerService.actualizarEvaluacion(evaluacion);
			if(actEval > 0){
					//Si se actualiza la evaluación se cambia el estado del evaluador a disponible y el estado de la solicitud
					this.alquilerService.actualizarEvaluador(evaluacion.getEvaluador().getIdEvaluador(), "Disponible", null);
					this.alquilerService.actualizarSolicitud(evaluacion.getSolicitud().getIdSolicitud(), evaluacion.getEstado());
					//Mandar correo...
					evaluacion = this.alquilerService.obtenerEvaluacion(evaluacion.getIdEvaluacion());
					EnvioMail e = new EnvioMail();
					e.envioMail(evaluacion.getSolicitud().getLocatario().getRazonSocial(),
								evaluacion.getSolicitud().getLocatario().getCorreo(),
								evaluacion.getEstado(),
								evaluacion.getSolicitud().getLocatario().getRepresentante(),
								evaluacion.getSolicitud().getLocatario().getRuc(),
								evaluacion.getFechaModif());
					
					context.addMessage(null, new FacesMessage("Información",  "La evaluación fue actualizada satisfactoriamente") );
			}
			else
				context.addMessage(null, new FacesMessage("Error",  "La evaluación presento problemas al ser actualizada") );
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		  context.getExternalContext().getFlash().setKeepMessages(true);
		  
		return "index";
	}
	
	public String cancelaEvaluacion(){
		return "evaluaciones";
	}

	public List<Evaluacion> getListaEvaluaciones() {
		return listaEvaluaciones;
	}

	public void setListaEvaluaciones(List<Evaluacion> listaEvaluaciones) {
		this.listaEvaluaciones = listaEvaluaciones;
	}

	public Evaluacion getEvaluacion() {
		return evaluacion;
	}

	public void setEvaluacion(Evaluacion evaluacion) {
		this.evaluacion = evaluacion;
	}

	public InfEstEmp getInfEstEmp() {
		return infEstEmp;
	}

	public void setInfEstEmp(InfEstEmp infEstEmp) {
		this.infEstEmp = infEstEmp;
	}

	public InfSanciones getInfSanciones() {
		return infSanciones;
	}

	public void setInfSanciones(InfSanciones infSanciones) {
		this.infSanciones = infSanciones;
	}

	public InfEvalMerc getInfEvalMerc() {
		return infEvalMerc;
	}

	public void setInfEvalMerc(InfEvalMerc infEvalMerc) {
		this.infEvalMerc = infEvalMerc;
	}
	public void addMessage(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}
	
	public void onRowSelect(SelectEvent event) {
		if(evaluacion.getEstado().equals("Aprobada")||evaluacion.getEstado().equals("Rechazada"))
			disabled = false;
		else
			disabled = true;
	}
	
	

}
