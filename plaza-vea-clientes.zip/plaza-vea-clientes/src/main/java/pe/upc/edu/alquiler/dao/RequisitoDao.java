package pe.upc.edu.alquiler.dao;

import java.util.List;

import pe.upc.edu.alquiler.model.Requisito;




public interface RequisitoDao {
	
	public List<Requisito> listarRequisitos() throws Exception;
	
}
